# Cashfree Payment Gateway for Paymenter

![](https://cdn.freelogovectors.net/wp-content/uploads/2022/09/cashfree-payments-logo-freelogovectors.net_.png)

A seamless Cashfree integration for Paymenter, enabling secure and efficient payment processing for your customers.

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](https://github.com/Sarthak-07/Cashfree-Paymenter/blob/main/LICENSE)
[![Compatibility Paymenter v1.x](https://img.shields.io/badge/Paymenter-v1.x-4B32C3.svg)](https://paymenter.org)

## Prerequisites

- Paymenter v1.x
- Cashfree Merchant Account

## Setup

1. **Install Cashfree Gateway Extension:** (Replace `/var/www/paymenter` with your paymenter root if it is different)
   - **Automatic Installation:** `git clone https://github.com/Sarthak-07/Cashfree-Paymenter.git /var/www/paymenter/extensions/Gateways/Cashfree`
   - **Manual Installation:** [Download](https://github.com/Sarthak-07/Cashfree-Paymenter/releases/latest/download/Cashfree.zip) the extension and extract it in `/var/www/paymenter/extensions/Gateways`
2. **Whitelist your website:** Before using the Cashfree Gateway Extension, you must whitelist your domain in the Cashfree Merchant Dashboard. [Read more](https://www.cashfree.com/docs/payments/online/go-live/whitelist#submitting-a-whitelist-request)
3. **Configure Webhooks:** Add Webhook Endpoint with event **`Success Payments`** in Cashfree Merchant Dashboard. Ensure the Endpoint URL format is `https://your.domain.name/extensions/gateways/cashfree/webhook`. [Read more](https://www.cashfree.com/docs/payments/online/webhooks/configure#add-webhook-endpoint)
4. **Enable Cashfree Gateway Extension:** Navigate to `Admin → Gateways → New Gateway → Cashfree` in Paymenter and follow the Configuration steps.

## Configuration

1. **Client APP ID:** Get Cashfree Client APP ID from [here](https://www.cashfree.com/docs/api-reference/authentication#generate-api-keys)

2. **Client Secret Key:** Get Cashfree Client Secret Key from [here](https://www.cashfree.com/docs/api-reference/authentication#generate-api-keys)

3. **Test APP ID (optional):** Get Cashfree Test APP ID from [here](https://www.cashfree.com/docs/api-reference/authentication#generate-api-keys)

4. **Test Secret Key (optional):** Get Cashfree Test Secret Key from [here](https://www.cashfree.com/docs/api-reference/authentication#generate-api-keys)

5. **Test Mode (optional):** Enable this if you want to test Cashfree Gateway Extension

Congratulations! Your Cashfree Payment Gateway Configuration is now complete!

## Support

For assistance, please reach out to me on Discord: [@sarthak77](https://discord.com/users/877064899065446461).
