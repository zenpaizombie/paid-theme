@assets
<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
@endassets

@script
<script>
    const cashfree = Cashfree({
        mode: "{{ $testMode ? 'sandbox' : 'production' }}"
    });
    cashfree.checkout({
        paymentSessionId: "{{ $paymentSessionId }}",
        returnUrl: "{{ route('invoices.show', ['invoice' => $invoice->id]) }}",
    });
</script>
@endscript