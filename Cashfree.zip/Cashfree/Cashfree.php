<?php

namespace Paymenter\Extensions\Gateways\Cashfree;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Helpers\ExtensionHelper;
use App\Classes\Extension\Gateway;
use Illuminate\Support\Facades\View;

class Cashfree extends Gateway
{
    public function boot()
    {
        require __DIR__ . '/routes/web.php';
        View::addNamespace('extensions.gateways.cashfree', __DIR__ . '/views');
    }

    public function getConfig($values = [])
    {
        return [
            [
                'name' => 'client_app_id',
                'label' => 'Client APP ID',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'client_secret_key',
                'label' => 'Client Secret Key',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'test_app_id',
                'label' => 'Test APP ID',
                'type' => 'text',
                'required' => false,
            ],
            [
                'name' => 'test_secret_key',
                'label' => 'Test Secret Key',
                'type' => 'text',
                'required' => false,
            ],
            [
                'name' => 'test_mode',
                'label' => 'Test Mode',
                'type' => 'checkbox',
                'required' => false,
            ],
        ];
    }

    public function pay($invoice, $total)
    {
        if ($invoice->currency_code !== "INR") {
            return view('extensions.gateways.cashfree::error', [
                'error' => 'The product currency code must be "INR" to make payments with Cashfree!',
            ]);
        }

        if (!$invoice->user->properties()->where('key', 'phone')->exists()) {
            return view('extensions.gateways.cashfree::error', [
                'error' => 'A valid phone number is required to make payments with Cashfree. Please update your account details with a phone number.',
            ]);
        }

        $appId = $this->config('test_mode') ? $this->config('test_app_id') : $this->config('client_app_id');
        $secretKey = $this->config('test_mode') ? $this->config('test_secret_key') : $this->config('client_secret_key');
        $url = $this->config('test_mode') ? 'https://sandbox.cashfree.com/pg/orders' : 'https://api.cashfree.com/pg/orders';

        $client = new Client();

        $payload = [
            'order_amount' => $total,
            'order_currency' => "INR",
            'customer_details' => [
                'customer_id' => (string)$invoice->user->id,
                'customer_name' => $invoice->user->name,
                'customer_email' => $invoice->user->email,
                'customer_phone' => $invoice->user->properties()->where('key', 'phone')->first()->value,
            ],
            'order_meta' => [
                'return_url' => route('invoices.show', ['invoice' => $invoice->id]),
                'notify_url' => route('extensions.gateways.cashfree.webhook'),
            ],
            'order_tags' => [
                'invoice_id' => (string)$invoice->id,
            ],
        ];

        try {
            $response = $client->post($url, [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'x-api-version' => '2025-01-01',
                    'x-client-id' => $appId,
                    'x-client-secret' => $secretKey,
                ],
                'json' => $payload,
            ]);

            $data = json_decode($response->getBody(), true);

            if (isset($data['payment_session_id'])) {
                return view('extensions.gateways.cashfree::pay', [
                    'invoice' => $invoice,
                    'paymentSessionId' => $data['payment_session_id'],
                    'testMode' => $this->config('test_mode'),
                ]);
            }
        } catch (\Exception $e) {
            throw new \Exception('Failed to create order: ' . $e->getMessage());
        }
    }

    public function webhook(Request $request)
    {
        $content = $request->getContent();
        $timestamp = $request->header('x-webhook-timestamp');
        $signature = $request->header('x-webhook-signature');
        $secretKey = $this->config('test_mode') ? $this->config('test_secret_key') : $this->config('client_secret_key');

        $payload = $timestamp . $content;
        $expected_signature = base64_encode(hash_hmac('sha256', $payload, $secretKey, true));

        if ($signature !== $expected_signature) {
            return response('Signature verification failed', 401);
        }

        $data = json_decode($content, true);

        $orderId = $data['data']['order']['order_id'];
        $orderAmount = $data['data']['order']['order_amount'];
        $invoice_id = (int)$data['data']['order']['order_tags']['invoice_id'];

        if ($data['type'] === 'PAYMENT_SUCCESS_WEBHOOK') {
            ExtensionHelper::addPayment($invoice_id, 'Cashfree', $orderAmount, null, $orderId);
        }
        return response('Webhook received and processed successfully');
    }
}
