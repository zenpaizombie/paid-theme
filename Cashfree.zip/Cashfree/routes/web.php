<?php

use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Gateways\Cashfree\Cashfree;

Route::post(
    '/extensions/gateways/cashfree/webhook',
    [Cashfree::class, 'webhook']
)->name('extensions.gateways.cashfree.webhook');
